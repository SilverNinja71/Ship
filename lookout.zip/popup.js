"use strict";
(() => {
  // src/core/labels.ts
  function verdictSourceShort(verdict) {
    switch (verdict.source) {
      case "gemini":
        return "Gemini";
      case "cache":
        return "Gemini (remembered)";
      case "heuristic":
        return "the Lookout's video groups";
      case "always-blocked":
        return "the always-blocked list";
      case "leisure-pass":
        return "a leisure pass";
    }
  }
  var PHASE_LABELS = {
    docked: "Docked",
    sailing: "Sailing (focus)",
    "shore-leave": "Shore leave (break)",
    drifting: "Drifting (paused)"
  };
  var GUARD_STATUS_LABELS = {
    guarding: "On watch: guarding this focus block",
    "no-voyage": "Off watch: Ship hasn't checked in yet. Open Ship to connect.",
    "not-focus": "Off watch: no focus block is running",
    stale: "Off watch: Ship stopped checking in. Is its tab still open?",
    ended: "Off watch: the focus block's time is up"
  };
  function formatTimeLeft(ms) {
    if (ms <= 0) return "time's up";
    if (ms < 6e4) return `${Math.ceil(ms / 1e3)} s left`;
    return `${Math.ceil(ms / 6e4)} min left`;
  }
  function formatClock(ms) {
    const total = Math.max(0, Math.ceil(ms / 1e3));
    const h = Math.floor(total / 3600);
    const m = Math.floor(total % 3600 / 60);
    const s = total % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  }
  function plural(n, one, many = `${one}s`) {
    return `${n} ${n === 1 ? one : many}`;
  }

  // src/shared/runtime.ts
  async function sendToBackground(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      return reply ?? null;
    } catch {
      return null;
    }
  }

  // src/popup/popup.ts
  var REFETCH_MS = 5e3;
  function el(doc, tag, className, text) {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function render(doc, root, state, clockNow) {
    const { voyage, stats } = state;
    const guarding = state.status === "guarding";
    const voyageCard = el(doc, "section", `card voyage ${guarding ? "on" : "off"}`);
    const top = el(doc, "div", "row");
    top.append(el(doc, "span", "phase", voyage ? PHASE_LABELS[voyage.phase] : "No voyage yet"));
    if (voyage?.endsAt != null) top.append(el(doc, "span", "clock", formatClock(voyage.endsAt - clockNow)));
    voyageCard.append(top);
    if (voyage?.assignment)
      voyageCard.append(el(doc, "p", "line", `${voyage.assignment.title}${voyage.assignment.course ? ` \xB7 ${voyage.assignment.course}` : ""}`));
    if (voyage?.objective) voyageCard.append(el(doc, "p", "line muted", `Objective: ${voyage.objective}`));
    voyageCard.append(el(doc, "p", `status ${guarding ? "good" : ""}`, GUARD_STATUS_LABELS[state.status]));
    const tiles = el(doc, "section", "tiles");
    for (const [n, label] of [
      [stats.blockedToday, "Sirens blocked"],
      [stats.steeredBackToday, "Steered back"],
      [stats.leisurePassesToday, "Leisure passes"]
    ]) {
      const tile = el(doc, "div", "tile");
      tile.append(el(doc, "strong", void 0, String(n)), el(doc, "span", void 0, label));
      tiles.append(tile);
    }
    const info = el(doc, "section", "card info");
    const gemini = el(doc, "p", `dot ${stats.geminiReady ? "good" : "warn"}`);
    gemini.textContent = stats.geminiReady ? `Gemini ready \xB7 ${state.geminiModel}` : "No Gemini key: the Lookout's video groups judge watch pages";
    info.append(gemini);
    if (state.geminiError && stats.geminiReady) {
      info.append(el(doc, "p", "small bad", `Last Gemini call failed ${formatAgo(clockNow - state.geminiError.at)}: ${state.geminiError.message}`));
    }
    if (state.lastVerdict) {
      const v = state.lastVerdict.verdict;
      const line = el(doc, "p", "small");
      line.append(
        "Last check: ",
        el(doc, "q", void 0, state.lastVerdict.title || "a video"),
        " ",
        el(doc, "b", v.decision === "PROCEED" ? "goodtext" : "badtext", v.decision === "PROCEED" ? "cleared" : "blocked"),
        ` by ${verdictSourceShort(v)}`
      );
      info.append(line);
    }
    for (const pass of state.passes) info.append(el(doc, "p", "small", `Leisure pass on ${pass.site}: ${formatTimeLeft(pass.until - clockNow)}`));
    info.append(
      el(
        doc,
        "p",
        "small",
        state.pendingRewards ? `${plural(state.pendingRewards, "reward")} (${state.pendingDoubloons} doubloons) waiting for Ship to collect` : "No rewards waiting: Ship has collected them all."
      ),
      el(doc, "p", "small muted", `${plural(state.cards, "flashcard")} aboard for the Siren Gate`)
    );
    const actions = el(doc, "div", "actions");
    const open = el(doc, "button", "btn", "Open Ship");
    open.type = "button";
    open.addEventListener("click", () => void sendToBackground({ t: "open-ship" }).then(() => window.close()));
    const settings = el(doc, "button", "btn ghost", "Settings");
    settings.type = "button";
    settings.addEventListener("click", () => void chrome.runtime.openOptionsPage());
    actions.append(open, settings);
    root.replaceChildren(voyageCard, tiles, info, actions);
  }
  function formatAgo(ms) {
    const min = Math.round(ms / 6e4);
    return min < 1 ? "just now" : min < 60 ? `${min} min ago` : `${Math.round(min / 60)} h ago`;
  }
  async function startPopup(doc = document) {
    const root = doc.getElementById("app");
    if (!root) return;
    let state = null;
    let fetchedAt = 0;
    const draw = () => {
      if (!state) return;
      render(doc, root, state, state.now + (Date.now() - fetchedAt));
    };
    const refetch = async () => {
      const next = await sendToBackground({ t: "popup-state" });
      if (!next) {
        root.replaceChildren(el(doc, "p", "card status", "The Lookout's background isn't answering. Try reloading the extension."));
        return;
      }
      state = next;
      fetchedAt = Date.now();
      draw();
    };
    await refetch();
    setInterval(draw, 1e3);
    setInterval(() => void refetch(), REFETCH_MS);
  }

  // src/popup/main.ts
  void startPopup();
})();
