"use strict";
(() => {
  // src/core/labels.ts
  function verdictSourceShort(verdict) {
    switch (verdict.source) {
      case "gemini":
        return "Gemini";
      case "cache":
        return "Gemini (remembered)";
      case "heuristic":
        return "the Lookout's video groups";
      case "always-blocked":
        return "the always-blocked list";
      case "leisure-pass":
        return "a leisure pass";
    }
  }
  var PHASE_LABELS = {
    docked: "Docked",
    sailing: "Sailing (focus)",
    "shore-leave": "Shore leave (break)",
    drifting: "Drifting (paused)"
  };
  var GUARD_STATUS_LABELS = {
    guarding: "On watch: guarding this focus block",
    "no-voyage": "Off watch: Ship hasn't checked in yet. Open Ship to connect.",
    "not-focus": "Off watch: no focus block is running",
    stale: "Off watch: Ship stopped checking in. Is its tab still open?",
    ended: "Off watch: the focus block's time is up"
  };
  function formatTimeLeft(ms) {
    if (ms <= 0) return "time's up";
    if (ms < 6e4) return `${Math.ceil(ms / 1e3)} s left`;
    return `${Math.ceil(ms / 6e4)} min left`;
  }
  function formatClock(ms) {
    const total = Math.max(0, Math.ceil(ms / 1e3));
    const h = Math.floor(total / 3600);
    const m = Math.floor(total % 3600 / 60);
    const s = total % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  }
  function plural(n, one, many = `${one}s`) {
    return `${n} ${n === 1 ? one : many}`;
  }

  // src/shared/runtime.ts
  async function sendToBackground(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      return reply ?? null;
    } catch {
      return null;
    }
  }

  // ../../packages/integrations/src/obsidian.ts
  var yamlString = (v) => /^[\w .,/@()-]*$/.test(v) && v.trim() === v && v !== "" && !/^(true|false|null|yes|no|\d)/i.test(v) ? v : JSON.stringify(v);
  function writeFrontmatter(properties) {
    const lines = ["---"];
    for (const [key, value] of Object.entries(properties)) {
      if (value === null || value === void 0 || value === "") continue;
      if (Array.isArray(value)) {
        if (!value.length) continue;
        lines.push(`${key}:`, ...value.map((v) => `  - ${yamlString(v)}`));
      } else lines.push(`${key}: ${yamlString(value)}`);
    }
    lines.push("---", "");
    return lines.join("\n");
  }
  function safeFileName(title, fallback = "Untitled") {
    const clean = title.replace(/[\\/:*?"<>|#^[\]]/g, " ").replace(/\s+/g, " ").trim().replace(/^\.+/, "").slice(0, 120).trim();
    return clean || fallback;
  }
  var isoDay = (ms) => new Date(ms - new Date(ms).getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  function clipToMarkdown(clip) {
    const published = clip.published && !Number.isNaN(Date.parse(clip.published)) ? isoDay(Date.parse(clip.published)) : null;
    const properties = writeFrontmatter({
      title: clip.title,
      source: clip.url,
      author: clip.author ? [clip.author] : null,
      published,
      created: isoDay(clip.created),
      description: clip.description?.replace(/\s+/g, " ").trim() || null,
      tags: [...new Set(["clippings", ...clip.tags ?? []].map((t) => t.replace(/^#/, "").trim()).filter(Boolean))]
    });
    return `${properties}${clip.content.trim()}
`;
  }

  // src/core/clips.ts
  function obsidianNewNoteUrl(fileName, folder, vault) {
    const path = [folder.trim().replace(/^\/+|\/+$/g, ""), fileName].filter(Boolean).join("/");
    const params = [`file=${encodeURIComponent(path)}`, "clipboard"];
    if (vault.trim()) params.unshift(`vault=${encodeURIComponent(vault.trim())}`);
    return `obsidian://new?${params.join("&")}`;
  }

  // src/popup/clipper.ts
  function el(doc, tag, className, text) {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function button(doc, label, className, onClick) {
    const b = el(doc, "button", `btn small ${className}`, label);
    b.type = "button";
    b.addEventListener("click", onClick);
    return b;
  }
  async function clipActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:/i.test(tab.url ?? "")) throw new Error("Only web pages can be clipped (not browser or extension pages).");
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/clipper.js"] });
    const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.__shipClipPage?.() ?? null });
    const clip = result?.result;
    if (!clip?.content) throw new Error("The Lookout couldn't find any text on this page.");
    return { clip, tabId: tab.id };
  }
  function startClipper(doc, root, settings) {
    const status = el(doc, "p", "small muted clip-status");
    status.setAttribute("aria-live", "polite");
    const say = (text, tone = "") => {
      status.className = `small clip-status ${tone || "muted"}`;
      status.textContent = text;
    };
    const idle = () => {
      const clipBtn = button(doc, "\u2702 Clip this page", "seafoam", () => void run());
      root.replaceChildren(
        el(doc, "p", "clip-title", "Web Clipper"),
        el(doc, "p", "small muted", "Saves the article as Markdown for Ship's Note Nook or Obsidian. Select text first to clip just that part."),
        clipBtn,
        status
      );
      const run = async () => {
        clipBtn.disabled = true;
        say("Reading the page\u2026");
        try {
          const { clip, tabId } = await clipActiveTab();
          editor(clip, tabId);
        } catch (e) {
          clipBtn.disabled = false;
          say(e instanceof Error ? e.message : String(e), "bad");
        }
      };
    };
    const editor = (clip, tabId) => {
      const title = el(doc, "input", "clip-input");
      title.value = clip.title;
      title.setAttribute("aria-label", "Title");
      const tags = el(doc, "input", "clip-input");
      tags.placeholder = "Tags, e.g. biology, unit-2";
      tags.setAttribute("aria-label", "Tags");
      const body = el(doc, "textarea", "clip-body");
      body.value = clip.content;
      body.rows = 9;
      body.setAttribute("aria-label", "Clipped text (Markdown)");
      const markdown = () => clipToMarkdown({
        title: title.value.trim() || clip.title,
        url: clip.url,
        content: body.value,
        author: clip.author,
        published: clip.published,
        description: clip.description,
        siteName: clip.siteName,
        tags: tags.value.split(/[,\s]+/).filter(Boolean),
        created: Date.now()
      });
      const save = async () => {
        const reply = await sendToBackground({ t: "save-clip", clip: { id: crypto.randomUUID(), title: title.value.trim() || clip.title, url: clip.url, markdown: markdown(), at: Date.now() } });
        if (!reply) return say("The Lookout couldn't keep that clip.", "bad");
        say(reply.waiting > 1 ? `Saved. Ship picks up ${reply.waiting} clips next time it's open.` : "Saved. It's in the Note Nook as soon as Ship is open.", "good");
      };
      const toObsidian = async () => {
        const s = settings();
        try {
          await navigator.clipboard.writeText(markdown());
          await chrome.tabs.update(tabId, { url: obsidianNewNoteUrl(safeFileName(title.value || clip.title), s?.clipFolder ?? "Clippings", s?.obsidianVault ?? "") });
          say("Sent. Obsidian opens with the new note (it needs to be installed).", "good");
        } catch (e) {
          say(`Couldn't send it: ${e instanceof Error ? e.message : String(e)}`, "bad");
        }
      };
      const copy = async () => {
        try {
          await navigator.clipboard.writeText(markdown());
          say("Copied as Markdown.", "good");
        } catch {
          say("The browser wouldn't copy it.", "bad");
        }
      };
      const download = () => {
        const url = URL.createObjectURL(new Blob([markdown()], { type: "text/markdown;charset=utf-8" }));
        const a = el(doc, "a");
        a.href = url;
        a.download = `${safeFileName(title.value || clip.title)}.md`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1e4);
      };
      const info = [clip.siteName, clip.author, `${clip.words} words`, clip.selection ? "selection" : null].filter(Boolean).join(" \xB7 ");
      const primary = el(doc, "div", "clip-actions");
      primary.append(button(doc, "Save to Ship", "seafoam", () => void save()), button(doc, "Send to Obsidian", "obsidian", () => void toObsidian()));
      const secondary = el(doc, "div", "clip-actions");
      secondary.append(button(doc, "Copy", "ghost", () => void copy()), button(doc, "Download .md", "ghost", download), button(doc, "Start over", "ghost", idle));
      root.replaceChildren(el(doc, "p", "clip-title", "Web Clipper"), title, el(doc, "p", "small muted", info), body, tags, primary, secondary, status);
      say("");
    };
    idle();
  }

  // src/popup/popup.ts
  var REFETCH_MS = 5e3;
  function el2(doc, tag, className, text) {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function render(doc, root, state, clockNow) {
    const { voyage, stats } = state;
    const guarding = state.status === "guarding";
    const voyageCard = el2(doc, "section", `card voyage ${guarding ? "on" : "off"}`);
    const top = el2(doc, "div", "row");
    top.append(el2(doc, "span", "phase", voyage ? PHASE_LABELS[voyage.phase] : "No voyage yet"));
    if (voyage?.endsAt != null) top.append(el2(doc, "span", "clock", formatClock(voyage.endsAt - clockNow)));
    voyageCard.append(top);
    if (voyage?.assignment)
      voyageCard.append(el2(doc, "p", "line", `${voyage.assignment.title}${voyage.assignment.course ? ` \xB7 ${voyage.assignment.course}` : ""}`));
    if (voyage?.objective) voyageCard.append(el2(doc, "p", "line muted", `Objective: ${voyage.objective}`));
    voyageCard.append(el2(doc, "p", `status ${guarding ? "good" : ""}`, GUARD_STATUS_LABELS[state.status]));
    const tiles = el2(doc, "section", "tiles");
    for (const [n, label] of [
      [stats.blockedToday, "Sirens blocked"],
      [stats.steeredBackToday, "Steered back"],
      [stats.leisurePassesToday, "Leisure passes"]
    ]) {
      const tile = el2(doc, "div", "tile");
      tile.append(el2(doc, "strong", void 0, String(n)), el2(doc, "span", void 0, label));
      tiles.append(tile);
    }
    const info = el2(doc, "section", "card info");
    const gemini = el2(doc, "p", `dot ${stats.geminiReady ? "good" : "warn"}`);
    gemini.textContent = stats.geminiReady ? `Gemini ready \xB7 ${state.geminiModel}` : "No Gemini key: the Lookout's video groups judge watch pages";
    info.append(gemini);
    if (state.geminiError && stats.geminiReady) {
      info.append(el2(doc, "p", "small bad", `Last Gemini call failed ${formatAgo(clockNow - state.geminiError.at)}: ${state.geminiError.message}`));
    }
    if (state.lastVerdict) {
      const v = state.lastVerdict.verdict;
      const line = el2(doc, "p", "small");
      line.append(
        "Last check: ",
        el2(doc, "q", void 0, state.lastVerdict.title || "a video"),
        " ",
        el2(doc, "b", v.decision === "PROCEED" ? "goodtext" : "badtext", v.decision === "PROCEED" ? "cleared" : "blocked"),
        ` by ${verdictSourceShort(v)}`
      );
      info.append(line);
    }
    for (const pass of state.passes) info.append(el2(doc, "p", "small", `Leisure pass on ${pass.site}: ${formatTimeLeft(pass.until - clockNow)}`));
    info.append(
      el2(
        doc,
        "p",
        "small",
        state.pendingRewards ? `${plural(state.pendingRewards, "reward")} (${state.pendingDoubloons} doubloons) waiting for Ship to collect` : "No rewards waiting: Ship has collected them all."
      ),
      el2(doc, "p", "small muted", `${plural(state.cards, "flashcard")} aboard for the Siren Gate`)
    );
    if (state.clipsWaiting) info.append(el2(doc, "p", "small", `${plural(state.clipsWaiting, "clip")} waiting for Ship's Note Nook`));
    const actions = el2(doc, "div", "actions");
    const open = el2(doc, "button", "btn", "Open Ship");
    open.type = "button";
    open.addEventListener("click", () => void sendToBackground({ t: "open-ship" }).then(() => window.close()));
    const settings = el2(doc, "button", "btn ghost", "Settings");
    settings.type = "button";
    settings.addEventListener("click", () => void chrome.runtime.openOptionsPage());
    actions.append(open, settings);
    root.replaceChildren(voyageCard, tiles, info, actions);
  }
  function formatAgo(ms) {
    const min = Math.round(ms / 6e4);
    return min < 1 ? "just now" : min < 60 ? `${min} min ago` : `${Math.round(min / 60)} h ago`;
  }
  async function startPopup(doc = document) {
    const root = doc.getElementById("app");
    if (!root) return;
    let state = null;
    let fetchedAt = 0;
    const draw = () => {
      if (!state) return;
      render(doc, root, state, state.now + (Date.now() - fetchedAt));
    };
    const refetch = async () => {
      const next = await sendToBackground({ t: "popup-state" });
      if (!next) {
        root.replaceChildren(el2(doc, "p", "card status", "The Lookout's background isn't answering. Try reloading the extension."));
        return;
      }
      state = next;
      fetchedAt = Date.now();
      draw();
    };
    const clipper = doc.getElementById("clipper");
    if (clipper) startClipper(doc, clipper, () => state);
    await refetch();
    setInterval(draw, 1e3);
    setInterval(() => void refetch(), REFETCH_MS);
  }

  // src/popup/main.ts
  void startPopup();
})();
