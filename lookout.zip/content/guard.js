"use strict";
(() => {
  // ../../packages/shared-types/src/voyage.ts
  var STEER_BACK_BONUS = 50;
  var GATE_LEISURE_MINUTES = 5;
  var GATE_CARDS_REQUIRED = 2;

  // ../../packages/shared-types/src/sprite.ts
  var SHIP_SPRITE = {
    hullBack: "hull-back",
    rigging: "rigging",
    hullFront: "hull-front",
    /** Optional: the ship's themed Captain's Quarters item (CABIN_DECOR). */
    cabinDecor: "cabin-decor",
    /** Optional: the Captain's Quarters backdrop, with a see-through porthole. */
    cabinRoom: "cabin-room"
  };
  var SHIP_Z = {
    behind: 0,
    hullBack: 10,
    rigging: 20,
    sails: 30,
    /** Deck details that must cover the foot of the sails. */
    deck: 40,
    /** Props and sailors. */
    onDeck: 50,
    hullFront: 60,
    figurehead: 70,
    flag: 80
  };
  var SHIP_DEFAULT_PLACEMENTS = [
    { sprite: SHIP_SPRITE.hullBack, x: 0, y: 0, zIndex: SHIP_Z.hullBack },
    { sprite: SHIP_SPRITE.rigging, x: 0, y: 0, zIndex: SHIP_Z.rigging },
    { sprite: SHIP_SPRITE.hullFront, x: 0, y: 0, zIndex: SHIP_Z.hullFront }
  ];

  // src/core/labels.ts
  function verdictSourceLabel(verdict, model) {
    switch (verdict.source) {
      case "gemini":
        return model ? `Judged by Gemini (${model})` : "Judged by Gemini";
      case "cache":
        return "Gemini's earlier verdict on this video";
      case "heuristic":
        return "Sorted by the Lookout's video groups, not Gemini";
      case "always-blocked":
        return "Always blocked during focus";
      case "leisure-pass":
        return "Leisure pass";
    }
  }
  function formatTimeLeft(ms) {
    if (ms <= 0) return "time's up";
    if (ms < 6e4) return `${Math.ceil(ms / 1e3)} s left`;
    return `${Math.ceil(ms / 6e4)} min left`;
  }
  function plural(n, one, many = `${one}s`) {
    return `${n} ${n === 1 ? one : many}`;
  }

  // ../../packages/active-recall-engine/src/text.ts
  var WORD_RE = new RegExp("[\\p{L}\\p{M}\\p{N}]+(?:['\u2019][\\p{L}]+)?(?:[.,]\\p{N}+)*", "gu");
  function normalizeWord(raw) {
    return raw.normalize("NFKD").replace(new RegExp("\\p{M}", "gu"), "").toLowerCase().replace(/['’]/g, "").replace(/(\d),(\d)/g, "$1$2");
  }
  function words(text) {
    const out = [];
    for (const m of text.matchAll(WORD_RE)) {
      const norm = normalizeWord(m[0]);
      if (norm) out.push({ raw: m[0], norm, start: m.index, end: m.index + m[0].length });
    }
    return out;
  }
  function normalize(text) {
    return words(text.replace(/&/g, " and ")).map((w) => w.norm).join(" ");
  }
  var STOPWORDS = new Set(
    `a about above after again against all almost also although always am among an and another any anything are around as at
  be became because become becomes been before being below between both but by can cannot could did do does doing done down
  during each either else etc even ever every few for from further get gets getting give given gives go goes going got had has
  have having he her here hers him his how however i if in into is it its itself just less like made main make makes making
  many may me might more most much must my near neither no nor not now of off often on once one only onto or other others
  our out over own per quite rather really same several she should since so some something sometimes still such than that
  the their them themselves then there therefore these they thing things this those though through thus to too toward towards
  two three four five six seven eight nine ten under until up upon us used uses using usually very via was way we well were
  what whatever when where whether which while who whom whose why will with within without would yet you your
  called known found seen shown take takes taken took happen happens happened occur occurs occurred include includes included
  including involve involves involved help helps allow allows let lets lead leads result results cause causes caused mean
  means refer refers describe describes example examples eg ie vs important different various new good bad large small big
  little high low part parts kind kinds type types lot lots begin begins began begun end ends ended start starts started
  bring brings bringing brought release releases released produce produces produced contain contains contained form forms
  formed become came come comes place consist consists provide provides provided require requires required create creates
  created put set keep keeps kept show shows turn turns need needs needed seem seems try tries`.split(/\s+/)
  );
  var NEGATIONS = /* @__PURE__ */ new Set(["not", "no", "never", "none", "nor", "cannot", "neither", "without", "isnt", "arent", "wasnt", "werent", "dont", "doesnt", "didnt", "cant", "wont", "shouldnt", "couldnt"]);
  function isStopword(norm) {
    return STOPWORDS.has(norm);
  }
  function isNumber(norm) {
    return new RegExp("^\\p{N}+(?:\\.\\p{N}+)?$", "u").test(norm);
  }
  var VOWEL = /[aeiouy]/;
  function stem(word) {
    let w = word;
    if (w.length <= 3 || isNumber(w)) return w;
    if (w.endsWith("ies") && w.length > 4) w = w.slice(0, -3) + "y";
    else if (w.endsWith("sses")) w = w.slice(0, -2);
    else if (/(?:x|z|ch|sh)es$/.test(w)) w = w.slice(0, -2);
    else if (w.endsWith("s") && !/(?:ss|us|is)$/.test(w)) w = w.slice(0, -1);
    if (w.endsWith("ied") && w.length > 4) w = w.slice(0, -3) + "y";
    else if (w.endsWith("ed") && !w.endsWith("eed") && VOWEL.test(w.slice(0, -2)) && w.length > 4) w = restoreBase(w.slice(0, -2));
    else if (w.endsWith("ing") && VOWEL.test(w.slice(0, -3)) && w.length > 5) w = restoreBase(w.slice(0, -3));
    else if (w.endsWith("ly") && w.length > 5) w = w.slice(0, -2);
    return w;
  }
  function restoreBase(w) {
    if (/([^aeiouylsz])\1$/.test(w)) return w.slice(0, -1);
    if (/^[^aeiou]*[aeiouy][^aeiouwxy]$/.test(w)) return w + "e";
    return w;
  }
  function levenshtein(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    let cur = new Array(b.length + 1);
    for (let i = 1; i <= a.length; i++) {
      cur[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      }
      [prev, cur] = [cur, prev];
    }
    return prev[b.length];
  }
  function similarity(a, b) {
    const longest = Math.max(a.length, b.length);
    return longest === 0 ? 1 : 1 - levenshtein(a, b) / longest;
  }
  function allowedEdits(length) {
    if (length <= 4) return 0;
    if (length <= 7) return 1;
    if (length <= 11) return 2;
    return 3;
  }
  function wordMatch(a, b) {
    if (a === b) return 1;
    if (isNumber(a) || isNumber(b)) return 0;
    const sa = stem(a);
    const sb = stem(b);
    if (sa === sb) return 1;
    const longest = Math.max(sa.length, sb.length);
    if (Math.abs(sa.length - sb.length) > allowedEdits(longest)) return 0;
    const d = levenshtein(sa, sb);
    return d <= allowedEdits(longest) ? 1 - d / longest : 0;
  }
  function contentWords(text) {
    const all = normalize(text).split(" ").filter(Boolean);
    const content = all.filter((w) => !isStopword(w));
    return content.length ? content : all;
  }

  // ../../packages/active-recall-engine/src/grading.ts
  var CORRECT_SCORE = 0.9;
  var CLOSE_SCORE = 0.7;
  var FAST_ANSWER_MS = 5e3;
  var MAX_CHAR_COMPARE = 400;
  function acceptedAnswers(back) {
    const whole = back.trim();
    const out = /* @__PURE__ */ new Set([whole]);
    const parts = whole.split(/\s*(?:[;|\n]|\s\/\s)\s*/).filter((p) => p.trim());
    if (parts.length > 1) parts.forEach((p) => out.add(p.trim()));
    for (const a of [...out]) {
      const bare = a.replace(/\s*\([^)]*\)\s*/g, " ").trim();
      if (bare && bare !== a) out.add(bare);
    }
    return [...out];
  }
  function bestMatch(word, pool) {
    let best = 0;
    for (const p of pool) {
      best = Math.max(best, wordMatch(word, p));
      if (best === 1) break;
    }
    return best;
  }
  function compare(given, expected) {
    const g = normalize(given);
    const e = normalize(expected);
    if (!e) return { score: g ? 0 : 1, missing: [] };
    if (g === e) return { score: 1, missing: [] };
    if (!g) return { score: 0, missing: contentWords(expected) };
    const charScore = g.length <= MAX_CHAR_COMPARE && e.length <= MAX_CHAR_COMPARE ? similarity(g, e) : 0;
    const ew = contentWords(expected);
    const gw = contentWords(given);
    const eMatch = ew.map((w) => bestMatch(w, gw));
    const recall = eMatch.reduce((a, b) => a + b, 0) / ew.length;
    const precision = gw.reduce((a, w) => a + bestMatch(w, ew), 0) / gw.length;
    const tokenScore = recall + precision === 0 ? 0 : 5 * precision * recall / (4 * precision + recall);
    let score = Math.max(charScore, tokenScore);
    const gAll = g.split(" ");
    const numbersOk = e.split(" ").filter(isNumber).every((n) => gAll.includes(n));
    if (!numbersOk) score = Math.min(score, 0.4);
    const negations = (s) => s.split(" ").filter((w) => NEGATIONS.has(w)).length % 2;
    if (negations(g) !== negations(e)) score = Math.min(score, 0.5);
    return { score, missing: ew.filter((_, i) => eMatch[i] === 0) };
  }
  function verdictFor(score) {
    if (score >= CORRECT_SCORE) return "correct";
    if (score >= CLOSE_SCORE) return "close";
    return "incorrect";
  }
  function gradeTypedAnswer(given, back, options = {}) {
    let best = { score: -1, missing: [], against: back };
    for (const accepted of acceptedAnswers(back)) {
      const c = compare(given, accepted);
      if (c.score > best.score) best = { ...c, against: accepted };
      if (c.score === 1) break;
    }
    const score = Math.max(0, best.score);
    const verdict = verdictFor(score);
    let suggestedRating;
    if (verdict === "correct") {
      const fast = options.responseMs !== void 0 && options.responseMs <= FAST_ANSWER_MS;
      suggestedRating = score === 1 && fast ? 5 : 4;
    } else if (verdict === "close") suggestedRating = 3;
    else suggestedRating = score >= 0.4 ? 2 : 1;
    return { score, verdict, suggestedRating, missing: best.missing, matchedAgainst: best.against };
  }

  // src/core/quiz.ts
  function canQuiz(cards, required = GATE_CARDS_REQUIRED) {
    return cards.length >= required;
  }
  function shuffled(items, random = Math.random) {
    const out = [...items];
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }
  function startQuiz(cards, now, required = GATE_CARDS_REQUIRED) {
    const state = { cards: [...cards], index: 0, correct: 0, required, phase: "asking", last: null, askedAt: now };
    return cards.length < required ? { ...state, phase: "exhausted" } : state;
  }
  function currentCard(state) {
    return state.phase === "asking" || state.phase === "missed" ? state.cards[state.index] ?? null : null;
  }
  function advance(state, now) {
    const index = state.index + 1;
    const left = state.cards.length - index;
    const phase = left < state.required - state.correct ? "exhausted" : "asking";
    return { ...state, index, phase, askedAt: now };
  }
  function submitAnswer(state, given, now) {
    const card = currentCard(state);
    if (state.phase !== "asking" || !card || !given.trim()) return state;
    const grade = gradeTypedAnswer(given, card.back, { responseMs: Math.max(0, now - state.askedAt) });
    const accepted = grade.verdict !== "incorrect";
    const last = { card, given, grade, accepted };
    if (!accepted) return { ...state, phase: "missed", last };
    const correct = state.correct + 1;
    if (correct >= state.required) return { ...state, correct, phase: "passed", last };
    return advance({ ...state, correct, last }, now);
  }
  function nextCard(state, now) {
    return state.phase === "missed" ? advance(state, now) : state;
  }

  // src/gate/art.ts
  var SIREN_SVG = `
<svg viewBox="0 0 200 200" role="img" aria-label="A cartoon siren in a pirate hat, singing on a rock" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <clipPath id="lk-frame"><rect width="200" height="200" rx="30"/></clipPath>
    <clipPath id="lk-shirt"><path d="M83 104 C83 95 91 91 100 91 C109 91 117 95 117 104 L119 134 L81 134 Z"/></clipPath>
    <linearGradient id="lk-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1D2D52"/><stop offset="1" stop-color="#31507A"/></linearGradient>
  </defs>
  <g clip-path="url(#lk-frame)">
    <rect width="200" height="200" fill="url(#lk-sky)"/>
    <circle cx="156" cy="40" r="15" fill="#FBF3E4"/>
    <circle cx="163" cy="35" r="13" fill="#21335A"/>
    <g fill="#FBF3E4" opacity=".75"><circle cx="30" cy="30" r="1.8"/><circle cx="58" cy="54" r="1.3"/><circle cx="118" cy="22" r="1.6"/><circle cx="182" cy="82" r="1.3"/><circle cx="20" cy="96" r="1.2"/></g>
    <g class="lk-notes" fill="#E8C770">
      <ellipse cx="143" cy="96" rx="5.5" ry="4.2" transform="rotate(-20 143 96)"/><rect x="146.6" y="74" width="2.6" height="22" rx="1"/><path d="M149 74 q9 3 8 12 q-2-6-8-7z"/>
      <ellipse cx="166" cy="72" rx="4.4" ry="3.4" transform="rotate(-20 166 72)"/><rect x="169" y="55" width="2.2" height="17" rx="1"/><path d="M171 55 q7 2 6 9 q-2-4-6-5z"/>
    </g>
    <path d="M30 172 C36 140 76 128 104 132 C134 128 164 142 172 172 Z" fill="#5E6478"/>
    <path d="M58 146 C70 137 90 134 104 136" stroke="#7E8499" stroke-width="4" fill="none" stroke-linecap="round"/>
    <path d="M97 128 C93 147 113 157 137 151 C151 147 157 139 161 131" stroke="#2FA38A" stroke-width="17" fill="none" stroke-linecap="round"/>
    <path d="M108 146 q5 -4 10 0 M124 148 q5 -4 10 0 M140 143 q4 -4 9 -1" stroke="#9FE3CF" stroke-width="2" fill="none" opacity=".7" stroke-linecap="round"/>
    <path d="M158 133 C159 117 171 110 181 112 C175 120 172 126 167 134 C177 134 185 142 187 151 C177 149 166 143 158 137 Z" fill="#3FB59A"/>
    <path d="M73 80 C68 54 87 42 100 42 C119 42 134 56 129 81 C133 101 131 121 121 131 L79 131 C69 119 69 99 73 80 Z" fill="#E2604F"/>
    <path d="M83 104 C83 95 91 91 100 91 C109 91 117 95 117 104 L119 134 L81 134 Z" fill="#FBF3E4"/>
    <g clip-path="url(#lk-shirt)" stroke="#1B2A4A" stroke-width="4"><path d="M76 108 H124 M76 117 H124 M76 126 H124"/></g>
    <path d="M86 104 C78 112 76 122 80 130" stroke="#F2C59B" stroke-width="7" fill="none" stroke-linecap="round"/>
    <path d="M114 103 C124 99 130 92 132 85" stroke="#F2C59B" stroke-width="7" fill="none" stroke-linecap="round"/>
    <path d="M125 83 C127 70 140 65 147 71 C148 80 139 89 128 89 Z" fill="#F6D7A7" stroke="#C9A04E" stroke-width="2"/>
    <path d="M131 85 L141 72 M128 84 L136 70" stroke="#C9A04E" stroke-width="1.5"/>
    <circle cx="100" cy="72" r="20" fill="#F2C59B"/>
    <path d="M80 71 C82 57 94 50 104 52 C113 54 119 60 121 69 C113 63 101 62 93 64 C88 66 84 68 80 71 Z" fill="#E2604F"/>
    <ellipse cx="93" cy="74" rx="2.5" ry="3.1" fill="#1B2A4A"/><ellipse cx="107" cy="74" rx="2.5" ry="3.1" fill="#1B2A4A"/>
    <circle cx="94" cy="73" r=".9" fill="#fff"/><circle cx="108" cy="73" r=".9" fill="#fff"/>
    <circle cx="87.5" cy="80" r="3.4" fill="#E2604F" opacity=".35"/><circle cx="112.5" cy="80" r="3.4" fill="#E2604F" opacity=".35"/>
    <ellipse cx="100" cy="84.5" rx="3.3" ry="2.8" fill="#B5473B"/>
    <path d="M73 57 C84 50 92 53 100 46 C108 53 116 50 127 57 C121 44 112 33 100 33 C88 33 79 44 73 57 Z" fill="#1B2A4A"/>
    <path d="M73 57 C84 50 92 53 100 46 C108 53 116 50 127 57" stroke="#C9A04E" stroke-width="3" fill="none" stroke-linecap="round"/>
    <circle cx="100" cy="40" r="3.4" fill="#C9A04E"/>
    <path d="M0 166 C20 158 36 174 56 166 S92 158 112 166 S148 174 168 166 S196 160 200 164 L200 200 L0 200 Z" fill="#2C8C77"/>
    <path d="M0 178 C22 170 40 186 62 178 S100 170 122 178 S160 186 182 178 S200 174 200 174 L200 200 L0 200 Z" fill="#3FB59A"/>
    <g fill="#DDF3EC" opacity=".8"><circle cx="40" cy="182" r="1.8"/><circle cx="96" cy="188" r="1.5"/><circle cx="150" cy="184" r="1.8"/></g>
  </g>
</svg>`;
  var CARDS_ICON = `<svg viewBox="0 0 34 34" aria-hidden="true"><rect x="9" y="5" width="18" height="24" rx="3" fill="#F3E8D2" stroke="#C9A04E" stroke-width="2" transform="rotate(12 18 17)"/><rect x="6" y="6" width="18" height="24" rx="3" fill="#FFFDF7" stroke="#1B2A4A" stroke-width="2"/><path d="M10 13h10M10 18h7" stroke="#3FB59A" stroke-width="2.4" stroke-linecap="round"/></svg>`;
  var WHEEL_ICON = `<svg viewBox="0 0 34 34" aria-hidden="true"><g stroke="#E8C770" stroke-width="2.4" stroke-linecap="round" fill="none"><circle cx="17" cy="17" r="8.5"/><path d="M17 3v28M3 17h28M7.1 7.1l19.8 19.8M26.9 7.1L7.1 26.9"/></g><circle cx="17" cy="17" r="3.4" fill="#E8C770"/></svg>`;
  var SPYGLASS_ICON = `<svg viewBox="0 0 24 24" aria-hidden="true"><g transform="rotate(-30 12 12)"><rect x="2" y="9.5" width="7" height="5" rx="1" fill="#C9A04E"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.2" fill="#E8C770"/><rect x="15" y="7.5" width="7" height="9" rx="1.5" fill="#C9A04E"/></g></svg>`;

  // src/gate/styles.ts
  var FONT = `ui-rounded, "SF Pro Rounded", Nunito, "Trebuchet MS", "Segoe UI", system-ui, sans-serif`;
  var GATE_CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
.backdrop {
  position: absolute; inset: 0; display: flex; padding: 16px; overflow-y: auto;
  background: radial-gradient(ellipse at 50% 115%, rgba(63, 181, 154, 0.35), transparent 60%), rgba(12, 21, 40, 0.9);
  backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px);
  font-family: ${FONT}; font-size: 15px; line-height: 1.45; color: #1B2A4A; text-align: left;
}
.card {
  position: relative; width: min(660px, 100%); margin: auto; padding: 22px;
  background: #FBF3E4; border: 3px solid #C9A04E; border-radius: 24px;
  box-shadow: 0 0 0 6px rgba(251, 243, 228, 0.12), 0 24px 60px rgba(0, 0, 0, 0.45);
  display: grid; grid-template-columns: 150px 1fr; gap: 4px 20px;
}
.art svg { display: block; width: 150px; height: 150px; }
.lk-notes { animation: lk-float 3.6s ease-in-out infinite; transform-origin: center; }
@keyframes lk-float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
.kicker { margin: 4px 0 0; font-size: 12px; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase; color: #8A6A2B; }
h1 { margin: 2px 0 6px; font-size: 26px; line-height: 1.15; font-weight: 800; color: #1B2A4A; }
.reason { margin: 0 0 10px; font-size: 15px; overflow-wrap: anywhere; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; }
.chip { font-size: 12px; font-weight: 700; border-radius: 999px; padding: 3px 10px; background: #EFE3CB; color: #5B4A2A; border: 1px solid #DCC9A2; }
.chip.gemini, .chip.cache { background: #DDF3EC; color: #1E6B58; border-color: #A8DCCB; }
.chip.heuristic { background: #FFF1D6; color: #8A5A00; border-color: #E9C987; }
.chip.always-blocked { background: #FBE1DD; color: #A33A2C; border-color: #F0B3AA; }
.voyage { grid-column: 1 / -1; margin: 10px 0 0; padding: 8px 12px; border-radius: 12px; background: #F3E8D2; font-size: 13.5px; color: #3A4866; overflow-wrap: anywhere; }
.panel { grid-column: 1 / -1; margin-top: 14px; }
.choices { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.choice {
  appearance: none; font: inherit; text-align: left; cursor: pointer; border-radius: 16px; padding: 14px 16px;
  border: 2px solid; display: flex; gap: 12px; align-items: flex-start; transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.choice:hover:not([disabled]) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(27, 42, 74, 0.2); }
.choice[disabled] { cursor: progress; opacity: 0.7; }
.choice.quiz { background: #FFFDF7; border-color: #C9A04E; color: #1B2A4A; }
.choice.steer { background: #1B2A4A; border-color: #1B2A4A; color: #FBF3E4; }
.choice .icon { flex: none; width: 34px; height: 34px; }
.choice .icon svg { width: 34px; height: 34px; display: block; }
.choice strong { display: block; font-size: 16px; line-height: 1.25; }
.choice .sub { display: block; font-size: 13px; opacity: 0.85; margin-top: 3px; }
.choice.steer .sub { color: #E8C770; opacity: 1; font-weight: 700; }
button:focus-visible, input:focus-visible { outline: 3px solid #3FB59A; outline-offset: 2px; }
.note { border: 2px dashed #C9A04E; border-radius: 16px; padding: 12px 14px; background: #FFFDF7; font-size: 13.5px; }
.note strong { display: block; font-size: 15px; margin-bottom: 2px; }
.quizhead { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 13px; font-weight: 700; color: #5B4A2A; }
.pips { display: inline-flex; gap: 5px; margin-left: 8px; vertical-align: -2px; }
.pip { width: 13px; height: 13px; border-radius: 50%; border: 2px solid #C9A04E; background: #FFFDF7; }
.pip.on { background: #3FB59A; border-color: #2C8C77; }
.front { background: #FFFDF7; border: 2px solid #E4D3AE; border-radius: 16px; padding: 14px 16px; font-size: 18px; font-weight: 700; min-height: 60px; white-space: pre-wrap; overflow-wrap: anywhere; }
.front small { display: block; font-size: 11px; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase; color: #8A6A2B; margin-bottom: 4px; }
form { display: flex; gap: 8px; margin: 10px 0 0; }
label.sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
input[type="text"] {
  flex: 1; min-width: 0; font: inherit; font-size: 16px; padding: 10px 12px; border-radius: 12px;
  border: 2px solid #C9A04E; background: #FFFFFF; color: #1B2A4A;
}
input[type="text"][disabled] { background: #F3E8D2; }
.btn { appearance: none; font: inherit; font-weight: 800; cursor: pointer; border-radius: 12px; padding: 10px 16px; border: 2px solid #1B2A4A; background: #1B2A4A; color: #FBF3E4; }
.btn.ghost { background: transparent; color: #1B2A4A; }
.btn.seafoam { background: #3FB59A; border-color: #2C8C77; color: #0E2A23; }
.linkbtn { appearance: none; background: none; border: none; font: inherit; font-size: 13px; color: #2E5E8B; text-decoration: underline; cursor: pointer; padding: 2px 4px; }
.feedback { min-height: 22px; margin-top: 10px; font-size: 14px; }
.feedback.good { color: #1E6B58; font-weight: 700; }
.feedback.bad { color: #A33A2C; }
.answer { display: block; margin-top: 4px; padding: 8px 12px; border-radius: 10px; background: #FBE1DD; color: #7A2A20; font-weight: 700; overflow-wrap: anywhere; }
.actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
.done { text-align: center; padding: 10px 6px; border-radius: 16px; background: #DDF3EC; color: #1E4D42; }
.done.steered { background: #1B2A4A; color: #FBF3E4; }
.done strong { display: block; font-size: 18px; margin-bottom: 2px; }
.done .gold { color: #E8C770; }
.foot { grid-column: 1 / -1; margin: 14px 0 0; font-size: 12px; color: #7A6A4E; text-align: center; }
@media (max-width: 600px) {
  .card { grid-template-columns: 1fr; text-align: center; padding: 18px; }
  .art { justify-self: center; }
  .art svg { width: 120px; height: 120px; }
  .chips { justify-content: center; }
  .choices { grid-template-columns: 1fr; }
  .choice, .front, .feedback, .quizhead { text-align: left; }
  h1 { font-size: 22px; }
}
@media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }

.toast {
  position: fixed; right: 16px; bottom: 16px; max-width: min(380px, calc(100vw - 32px)); display: flex; gap: 10px; align-items: center;
  padding: 10px 14px; border-radius: 999px; background: #1B2A4A; color: #FBF3E4; border: 2px solid #C9A04E;
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.35); font-family: ${FONT}; font-size: 13.5px; line-height: 1.35;
}
.toast svg { width: 22px; height: 22px; flex: none; }
.toast.ok { border-color: #3FB59A; }
.toast small { display: block; opacity: 0.75; font-size: 11.5px; }
`;

  // src/gate/svg.ts
  var SVG_NS = "http://www.w3.org/2000/svg";
  var TAG = /<(\/?)([a-zA-Z][\w:-]*)((?:\s+[\w:-]+="[^"]*")*)\s*(\/?)>/g;
  var ATTR = /([\w:-]+)="([^"]*)"/g;
  function parseSvgMarkup(markup) {
    const root = { tag: "#root", attrs: {}, children: [] };
    const stack = [root];
    for (const [, closing, tag, attrText, selfClosing] of markup.matchAll(TAG)) {
      if (closing) {
        if (stack.length > 1) stack.pop();
        continue;
      }
      const node = { tag, attrs: Object.fromEntries([...attrText.matchAll(ATTR)].map((a) => [a[1], a[2]])), children: [] };
      stack.at(-1).children.push(node);
      if (!selfClosing) stack.push(node);
    }
    const svg = root.children[0];
    if (!svg || svg.tag !== "svg") throw new Error("Expected <svg> markup");
    return svg;
  }
  function build(doc, node) {
    const el = doc.createElementNS(SVG_NS, node.tag);
    for (const [k, v] of Object.entries(node.attrs)) if (k !== "xmlns" && !k.startsWith("on")) el.setAttribute(k, v);
    for (const child of node.children) el.append(build(doc, child));
    return el;
  }
  function svgElement(doc, markup) {
    return build(doc, parseSvgMarkup(markup));
  }

  // src/gate/gate.ts
  function makeH(doc) {
    return function h(tag, attrs = {}, ...children) {
      const el = doc.createElement(tag);
      for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
      for (const c of children) if (c) el.append(c);
      return el;
    };
  }
  function icon(doc, svg) {
    const span = doc.createElement("span");
    span.className = "icon";
    span.append(svgElement(doc, svg));
    return span;
  }
  function setImportant(el, styles) {
    for (const [k, v] of Object.entries(styles)) el.style.setProperty(k, v, "important");
  }
  var clock = (at) => new Date(at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  function mountSirenGate(options) {
    const container = options.container ?? document.documentElement;
    const doc = container.ownerDocument;
    const now = options.now ?? (() => Date.now());
    const h = makeH(doc);
    const fullPage = container === doc.documentElement;
    const host = doc.createElement("ship-lookout-gate");
    setImportant(host, {
      position: fullPage ? "fixed" : "absolute",
      inset: "0",
      "z-index": "2147483647",
      display: "block",
      margin: "0",
      padding: "0",
      border: "0",
      background: "transparent"
    });
    const root = host.attachShadow({ mode: "closed" });
    const style = doc.createElement("style");
    style.textContent = GATE_CSS;
    root.append(style);
    for (const type of ["keydown", "keyup", "keypress"]) root.addEventListener(type, (e) => e.stopPropagation());
    let cards = null;
    let view = { name: "choices" };
    let busy = false;
    let focusSelector = ".choice";
    const cleanups = [];
    const titleId = "lk-title";
    const reasonId = "lk-reason";
    const panel = h("div", { class: "panel" });
    const voyageLine = h("p", { class: "voyage" });
    const sourceClass = options.verdict.source;
    const showConfidence = options.verdict.source === "gemini" || options.verdict.source === "heuristic" || options.verdict.source === "cache";
    const card = h(
      "section",
      { class: "card", role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, "aria-describedby": reasonId },
      h("div", { class: "art" }, svgElement(doc, SIREN_SVG)),
      h(
        "div",
        { class: "body" },
        h("p", { class: "kicker" }, "The Lookout spotted a siren"),
        h("h1", { id: titleId }, "Avast! Hold your course."),
        h("p", { class: "reason", id: reasonId }, options.verdict.reason),
        h(
          "div",
          { class: "chips" },
          h("span", { class: `chip ${sourceClass}` }, verdictSourceLabel(options.verdict, options.voyage.geminiModel)),
          showConfidence && h("span", { class: "chip" }, `Confidence ${Math.round(options.verdict.confidence * 100)}%`),
          h("span", { class: "chip" }, options.site)
        )
      ),
      voyageLine,
      panel,
      h("p", { class: "foot" }, "The Lookout only stands watch during focus blocks.")
    );
    const backdrop = h("div", { class: "backdrop" }, card);
    root.append(backdrop);
    function renderVoyageLine() {
      const { objective, assignment, endsAt } = options.voyage;
      const parts = [];
      if (assignment) parts.push(`Studying: ${assignment}`);
      if (objective && objective !== assignment) parts.push(`Objective: ${objective}`);
      if (endsAt !== null) parts.push(`${formatTimeLeft(endsAt - now())} in this focus block`);
      voyageLine.textContent = parts.join(" \xB7 ") || "A focus block is underway.";
    }
    function choicesView() {
      const steer = h(
        "button",
        { class: "choice steer", type: "button", "data-action": "steer" },
        icon(doc, WHEEL_ICON),
        h("span", {}, h("strong", {}, "Steer back to the ship"), h("span", { class: "sub" }, `+${STEER_BACK_BONUS} doubloons`))
      );
      steer.addEventListener("click", () => void steerBack());
      let quiz;
      if (cards === null) {
        quiz = h(
          "button",
          { class: "choice quiz", type: "button", disabled: "" },
          icon(doc, CARDS_ICON),
          h("span", {}, h("strong", {}, "Loading flashcards\u2026"), h("span", { class: "sub" }, "Checking which cards Ship sent"))
        );
      } else if (canQuiz(cards)) {
        const btn = h(
          "button",
          { class: "choice quiz", type: "button", "data-action": "quiz" },
          icon(doc, CARDS_ICON),
          h(
            "span",
            {},
            h("strong", {}, `Answer ${plural(GATE_CARDS_REQUIRED, "flashcard")}`),
            h("span", { class: "sub" }, `Earn a ${GATE_LEISURE_MINUTES}-minute leisure pass for ${options.site}`)
          )
        );
        btn.addEventListener("click", () => {
          const deck = shuffled(cards ?? [], options.random);
          view = { name: "quiz", quiz: startQuiz(deck, now()) };
          focusSelector = "input";
          render();
        });
        quiz = btn;
      } else {
        const have = cards.length === 0 ? "No flashcards are aboard yet." : `Only ${plural(cards.length, "flashcard")} aboard.`;
        quiz = h(
          "div",
          { class: "note", role: "note" },
          h("strong", {}, "No leisure pass this time"),
          `${have} Open Ship and it sends your due cards to the Lookout; answering ${GATE_CARDS_REQUIRED} of them earns a ${GATE_LEISURE_MINUTES}-minute pass.`
        );
      }
      return [h("div", { class: "choices" }, quiz, steer)];
    }
    function quizView(quiz) {
      const pips = h("span", { class: "pips", "aria-hidden": "true" });
      for (let i = 0; i < quiz.required; i++) pips.append(h("span", { class: `pip${i < quiz.correct ? " on" : ""}` }));
      const back = h("button", { class: "linkbtn", type: "button" }, "Back");
      back.addEventListener("click", () => {
        view = { name: "choices" };
        focusSelector = ".choice";
        render();
      });
      const head = h("div", { class: "quizhead" }, h("span", {}, `${quiz.correct} of ${quiz.required} correct`, pips), back);
      const feedback = h("div", { class: "feedback", role: "status", "aria-live": "polite" });
      const out = [head];
      if (quiz.phase === "exhausted") {
        feedback.classList.add("bad");
        feedback.append("That's every flashcard aboard, and not enough were right for a pass. Review them in Ship, or steer back now.");
        const steer = h("button", { class: "btn", type: "button", "data-action": "steer" }, `Steer back (+${STEER_BACK_BONUS} doubloons)`);
        steer.addEventListener("click", () => void steerBack());
        focusSelector = "[data-action=steer]";
        return [...out, feedback, h("div", { class: "actions" }, steer)];
      }
      const c = currentCard(quiz);
      if (!c) return out;
      out.push(h("div", { class: "front" }, h("small", {}, "Flashcard"), c.front));
      const missed = quiz.phase === "missed";
      const input = h("input", {
        type: "text",
        id: "lk-answer",
        autocomplete: "off",
        spellcheck: "false",
        placeholder: "Type your answer",
        "aria-label": "Your answer"
      });
      if (missed) {
        input.value = quiz.last?.given ?? "";
        input.disabled = true;
      }
      const submit = h("button", { class: "btn seafoam", type: "submit" }, "Check");
      if (missed) submit.disabled = true;
      const form = h("form", {}, input, submit);
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const current = view.name === "quiz" ? view.quiz : null;
        if (!current || !input.value.trim()) return;
        const next = submitAnswer(current, input.value, now());
        view = { name: "quiz", quiz: next };
        if (next.phase === "passed") void passed();
        else {
          focusSelector = next.phase === "missed" ? "[data-action=next]" : "input";
          render();
        }
      });
      out.push(form);
      if (missed && quiz.last) {
        feedback.classList.add("bad");
        feedback.append("Not quite. The answer was:", h("span", { class: "answer" }, quiz.last.card.back));
        const next = h("button", { class: "btn", type: "button", "data-action": "next" }, "Try another card");
        next.addEventListener("click", () => {
          if (view.name !== "quiz") return;
          view = { name: "quiz", quiz: nextCard(view.quiz, now()) };
          focusSelector = "input";
          render();
        });
        out.push(feedback, h("div", { class: "actions" }, next));
      } else {
        if (quiz.last?.accepted) {
          feedback.classList.add("good");
          const left = quiz.required - quiz.correct;
          feedback.append(`${quiz.last.grade.verdict === "close" ? "Close enough, aye!" : "Aye, that's right!"} ${plural(left, "more card")} to go.`);
        }
        out.push(feedback);
      }
      return out;
    }
    function doneView() {
      if (view.name === "passed") {
        return [
          h(
            "div",
            { class: "done", role: "status" },
            h("strong", {}, "Leisure pass granted!"),
            `Enjoy ${GATE_LEISURE_MINUTES} minutes on ${options.site}. The Lookout is back on watch at ${clock(view.until)}.`
          )
        ];
      }
      if (view.name === "steered") {
        const { doubloons } = view.result;
        const pay = doubloons > 0 ? h("span", { class: "gold" }, `+${doubloons} doubloons`) : null;
        return [
          h(
            "div",
            { class: "done steered", role: "status" },
            h("strong", {}, "Steered back to the ship!"),
            pay ? pay : "The steer-back bonus pays once every 10 minutes, so no doubloons this time.",
            pay ? " are waiting aboard Ship." : "",
            h("br"),
            "This tab stays docked until the focus block ends."
          )
        ];
      }
      return [h("div", { class: "done steered", role: "status" }, h("strong", {}, "Setting sail for Ship\u2026"), "Hold tight.")];
    }
    function render() {
      renderVoyageLine();
      const nodes = view.name === "choices" ? choicesView() : view.name === "quiz" ? quizView(view.quiz) : doneView();
      panel.replaceChildren(...nodes);
      if (focusSelector) {
        const target = panel.querySelector(`${focusSelector}:not([disabled])`);
        target?.focus();
        focusSelector = null;
      }
    }
    async function steerBack() {
      if (busy) return;
      busy = true;
      view = { name: "sailing" };
      render();
      const result = await options.client.steerBack();
      busy = false;
      if (result?.focusedExistingTab) view = { name: "steered", result };
      else if (!result) view = { name: "choices" };
      render();
    }
    async function passed() {
      if (busy) return;
      busy = true;
      const result = await options.client.passed();
      busy = false;
      if (!result) {
        view = { name: "choices" };
        render();
        return;
      }
      view = { name: "passed", until: result.passUntil };
      render();
      const timer = setTimeout(() => options.onPassed?.(result.passUntil), 1600);
      cleanups.push(() => clearTimeout(timer));
    }
    root.addEventListener("keydown", (e) => {
      const ke = e;
      if (ke.key !== "Tab") return;
      const focusables = [...root.querySelectorAll("button:not([disabled]), input:not([disabled])")];
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const active = root.activeElement;
      if (ke.shiftKey && (active === first || !active)) {
        ke.preventDefault();
        last.focus();
      } else if (!ke.shiftKey && (active === last || !active)) {
        ke.preventDefault();
        first.focus();
      }
    });
    const exitFullscreen = () => {
      if (doc.fullscreenElement) void doc.exitFullscreen().catch(() => void 0);
    };
    doc.addEventListener("fullscreenchange", exitFullscreen);
    cleanups.push(() => doc.removeEventListener("fullscreenchange", exitFullscreen));
    exitFullscreen();
    const applyInert = () => {
      const target = options.inertTarget === void 0 ? doc.body : options.inertTarget;
      if (!target) return;
      const was = target.inert;
      target.inert = true;
      cleanups.push(() => {
        target.inert = was;
      });
    };
    if (options.inertTarget === void 0 && !doc.body) {
      const onReady = () => applyInert();
      doc.addEventListener("DOMContentLoaded", onReady, { once: true });
      cleanups.push(() => doc.removeEventListener("DOMContentLoaded", onReady));
    } else applyInert();
    if (fullPage) {
      const html = doc.documentElement;
      const overflow = html.style.getPropertyValue("overflow");
      const priority = html.style.getPropertyPriority("overflow");
      html.style.setProperty("overflow", "hidden", "important");
      cleanups.push(() => html.style.setProperty("overflow", overflow, priority));
    }
    const ticker = setInterval(renderVoyageLine, 15e3);
    cleanups.push(() => clearInterval(ticker));
    container.append(host);
    render();
    void options.client.cards().then((list) => {
      cards = list;
      if (view.name === "choices") {
        focusSelector = ".choice";
        render();
      }
    });
    return {
      host,
      destroy() {
        for (const fn of cleanups.splice(0)) fn();
        host.remove();
      }
    };
  }
  function mountToast(text, container = document.documentElement) {
    const doc = container.ownerDocument;
    const host = doc.createElement("ship-lookout-toast");
    setImportant(host, { position: "fixed", inset: "auto 0 0 auto", "z-index": "2147483646", display: "block" });
    const root = host.attachShadow({ mode: "closed" });
    const style = doc.createElement("style");
    style.textContent = GATE_CSS;
    const box = doc.createElement("div");
    box.className = "toast";
    box.setAttribute("role", "status");
    const label = doc.createElement("div");
    box.append(icon(doc, SPYGLASS_ICON), label);
    root.append(style, box);
    container.append(host);
    const toast = {
      set(t, detail, ok = false) {
        label.replaceChildren(t);
        if (detail) {
          const small = doc.createElement("small");
          small.textContent = detail;
          label.append(small);
        }
        box.classList.toggle("ok", ok);
      },
      remove() {
        host.remove();
      }
    };
    toast.set(text);
    return toast;
  }

  // src/shared/runtime.ts
  async function sendToBackground(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      return reply ?? null;
    } catch {
      return null;
    }
  }

  // src/gate/client.ts
  function chromeGateClient(url) {
    return {
      cards: async () => (await sendToBackground({ t: "gate-cards" }))?.cards ?? [],
      passed: () => sendToBackground({ t: "gate-passed", url }),
      steerBack: () => sendToBackground({ t: "steer-back", url })
    };
  }

  // src/core/classify.ts
  var YOUTUBE_HOSTS = /* @__PURE__ */ new Set(["youtube.com", "www.youtube.com", "m.youtube.com"]);
  function isYouTubeHost(hostname) {
    return YOUTUBE_HOSTS.has(hostname.toLowerCase());
  }

  // src/content/media.ts
  function createMediaHush(doc) {
    let active = false;
    const paused = /* @__PURE__ */ new Set();
    const hush = (el) => {
      if (!el.paused) {
        el.pause();
        paused.add(el);
      }
    };
    const onPlay = (e) => {
      if (active && e.target instanceof HTMLMediaElement) hush(e.target);
    };
    doc.addEventListener("play", onPlay, true);
    doc.addEventListener("playing", onPlay, true);
    return {
      start() {
        active = true;
        doc.querySelectorAll("video, audio").forEach(hush);
      },
      stop(resume) {
        active = false;
        if (resume) {
          for (const el of paused) if (el.isConnected) el.play().catch(() => void 0);
        }
        paused.clear();
      }
    };
  }

  // src/content/youtubePage.ts
  function cleanYouTubeTitle(documentTitle) {
    return documentTitle.replace(/^\(\d+\+?\)\s*/, "").replace(/\s*-\s*YouTube$/, "").trim();
  }
  function collapse(text, max) {
    return (text ?? "").replace(/\s+/g, " ").trim().slice(0, max);
  }
  var firstText = (doc, selectors) => {
    for (const sel of selectors) {
      const t = collapse(doc.querySelector(sel)?.textContent, 300);
      if (t) return t;
    }
    return "";
  };
  var meta = (doc, selector) => collapse(doc.querySelector(selector)?.getAttribute("content"), 2e3);
  function watchPageReady(doc, videoId) {
    const flexy = doc.querySelector("ytd-watch-flexy");
    if (flexy) return flexy.getAttribute("video-id") === videoId && !!firstText(doc, ["ytd-watch-metadata h1"]);
    return cleanYouTubeTitle(doc.title).length > 0;
  }
  function readInspection(doc, videoId) {
    const canonical = doc.querySelector('link[rel="canonical"]')?.getAttribute("href") ?? "";
    const metaIsCurrent = canonical.includes(videoId);
    let title = firstText(doc, ["ytd-watch-metadata h1", "#title h1", "h1.title"]);
    if (!title && metaIsCurrent) title = meta(doc, 'meta[name="title"]') || meta(doc, 'meta[property="og:title"]');
    if (!title) title = cleanYouTubeTitle(doc.title);
    let channel = firstText(doc, ["ytd-watch-metadata ytd-channel-name a", "#owner ytd-channel-name a", "#upload-info #channel-name a"]);
    if (!channel && metaIsCurrent) channel = collapse(doc.querySelector('span[itemprop="author"] link[itemprop="name"]')?.getAttribute("content"), 120);
    let description = collapse(doc.querySelector("ytd-watch-metadata #description-inline-expander, ytd-watch-metadata #description")?.textContent, 2e3);
    if (!description && metaIsCurrent) description = meta(doc, 'meta[name="description"]') || meta(doc, 'meta[property="og:description"]');
    const category = metaIsCurrent ? collapse(doc.querySelector('meta[itemprop="genre"]')?.getAttribute("content"), 60) : "";
    return {
      videoId,
      title,
      channel,
      description,
      // Transcripts need YouTube's signed caption URLs; title, description and thumbnail are enough to judge.
      transcriptExcerpt: null,
      thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`,
      category: category || null
    };
  }

  // src/content/guard.ts
  var READY_TIMEOUT_MS = 4e3;
  var URL_POLL_MS = 1e3;
  var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function startGuard() {
    const hush = createMediaHush(document);
    let generation = 0;
    let gate = null;
    let gateUrl = null;
    let toast = null;
    let toastTimer;
    let passTimer;
    let lastUrl = location.href;
    let allowedUrl = null;
    function clearToast() {
      clearTimeout(toastTimer);
      toast?.remove();
      toast = null;
    }
    function unmountGate() {
      gate?.destroy();
      gate = null;
      gateUrl = null;
    }
    async function waitForWatchPage(videoId, gen) {
      const until = Date.now() + READY_TIMEOUT_MS;
      while (Date.now() < until) {
        if (gen !== generation) return false;
        if (watchPageReady(document, videoId)) {
          await sleep(300);
          return gen === generation;
        }
        await sleep(250);
      }
      return gen === generation;
    }
    function apply(decision, url, announce) {
      clearTimeout(passTimer);
      if (decision.action === "allow") {
        allowedUrl = url;
        unmountGate();
        hush.stop(announce);
        if (decision.passUntil !== null) passTimer = setTimeout(() => void evaluate(), Math.max(0, decision.passUntil - Date.now()) + 500);
        if (announce && decision.verdict) {
          toast ??= mountToast("");
          toast.set(
            "The Lookout cleared this video.",
            decision.verdict.source === "heuristic" ? `Video groups: ${decision.verdict.reason}` : decision.verdict.reason,
            true
          );
          toastTimer = setTimeout(clearToast, 4500);
        } else clearToast();
        return;
      }
      if (decision.action !== "block") return;
      allowedUrl = null;
      clearToast();
      hush.start();
      if (gate && gateUrl === url) return;
      unmountGate();
      gate = mountSirenGate({
        site: decision.site,
        verdict: decision.verdict,
        voyage: decision.voyage,
        client: chromeGateClient(url),
        onPassed: () => void evaluate()
      });
      gateUrl = url;
      void sendToBackground({ t: "blocked", url });
    }
    async function evaluate() {
      const gen = ++generation;
      const url = location.href;
      const decision = await sendToBackground({ t: "check", url });
      if (gen !== generation || !decision) return;
      if (decision.action !== "inspect") return apply(decision, url, false);
      if (gate && gateUrl === url) return;
      const loud = allowedUrl !== url;
      if (loud) {
        hush.start();
        clearToast();
        toast = mountToast("The Lookout is checking this video\u2026");
      }
      if (!await waitForWatchPage(decision.videoId, gen)) return;
      const judged = await sendToBackground({ t: "judge", url, inspection: readInspection(document, decision.videoId) });
      if (gen !== generation) return;
      apply(judged ?? { action: "allow", verdict: null, passUntil: null }, url, loud);
    }
    function onUrlMaybeChanged() {
      if (location.href === lastUrl) return;
      lastUrl = location.href;
      void evaluate();
    }
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.t === "lookout-refresh") void evaluate();
      return false;
    });
    if (isYouTubeHost(location.hostname)) {
      document.addEventListener("yt-navigate-finish", onUrlMaybeChanged);
      setInterval(onUrlMaybeChanged, URL_POLL_MS);
    }
    window.addEventListener("popstate", onUrlMaybeChanged);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") void evaluate();
    });
    void evaluate();
  }
  if (!globalThis.__shipLookoutGuard) {
    globalThis.__shipLookoutGuard = true;
    startGuard();
  }
})();
