"use strict";
(() => {
  // ../../packages/shared-types/src/lookout.ts
  var BRIDGE_PROTOCOL_VERSION = 1;
  var WEB_SOURCE = "ship-web";
  var LOOKOUT_SOURCE = "ship-lookout";
  var SHIP_APP_META = "ship-app";

  // ../../packages/shared-types/src/sprite.ts
  var SHIP_SPRITE = {
    hullBack: "hull-back",
    rigging: "rigging",
    hullFront: "hull-front",
    /** Optional: the ship's themed Captain's Quarters item (CABIN_DECOR). */
    cabinDecor: "cabin-decor",
    /** Optional: the Captain's Quarters backdrop, with a see-through porthole. */
    cabinRoom: "cabin-room"
  };
  var SHIP_Z = {
    behind: 0,
    hullBack: 10,
    rigging: 20,
    sails: 30,
    /** Deck details that must cover the foot of the sails. */
    deck: 40,
    /** Props and sailors. */
    onDeck: 50,
    hullFront: 60,
    figurehead: 70,
    flag: 80
  };
  var SHIP_DEFAULT_PLACEMENTS = [
    { sprite: SHIP_SPRITE.hullBack, x: 0, y: 0, zIndex: SHIP_Z.hullBack },
    { sprite: SHIP_SPRITE.rigging, x: 0, y: 0, zIndex: SHIP_Z.rigging },
    { sprite: SHIP_SPRITE.hullFront, x: 0, y: 0, zIndex: SHIP_Z.hullFront }
  ];

  // src/core/constants.ts
  var HEARTBEAT_STALE_MS = 3 * 6e4;
  var ENDS_AT_GRACE_MS = 2 * 6e4;
  var VERDICT_TTL_MS = 12 * 60 * 6e4;
  var MAX_CARDS = 50;
  var STEER_BACK_COOLDOWN_MS = 10 * 6e4;
  var THUMBNAIL_MAX_BYTES = 256 * 1024;

  // src/core/bridgeProtocol.ts
  var PHASES = /* @__PURE__ */ new Set(["docked", "sailing", "shore-leave", "drifting"]);
  var MAX_ACK_IDS = 1e3;
  var isRecord = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
  var finite = (v) => typeof v === "number" && Number.isFinite(v);
  function text(v, max) {
    if (typeof v !== "string") return null;
    const t = v.trim();
    return t ? t.slice(0, max) : null;
  }
  function parseVoyageState(v) {
    if (!isRecord(v)) return null;
    if (typeof v.phase !== "string" || !PHASES.has(v.phase)) return null;
    if (typeof v.guarding !== "boolean" || !finite(v.updatedAt)) return null;
    if (v.endsAt !== null && !finite(v.endsAt)) return null;
    if (v.objective !== null && typeof v.objective !== "string") return null;
    let assignment = null;
    if (v.assignment !== null) {
      if (!isRecord(v.assignment)) return null;
      const title = text(v.assignment.title, 300);
      if (title) assignment = { title, course: text(v.assignment.course, 200) };
    }
    return {
      phase: v.phase,
      guarding: v.guarding,
      endsAt: v.endsAt,
      objective: text(v.objective, 300),
      assignment,
      updatedAt: v.updatedAt
    };
  }
  function sanitizeCards(list) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const c of list) {
      if (out.length >= MAX_CARDS) break;
      if (!isRecord(c)) continue;
      const id = text(c.id, 200);
      const front = text(c.front, 1e3);
      const back = text(c.back, 500);
      if (!id || !front || !back || seen.has(id)) continue;
      seen.add(id);
      out.push({ id, front, back });
    }
    return out;
  }
  function parseWebMessage(data) {
    if (!isRecord(data) || data.source !== WEB_SOURCE) return null;
    const source = WEB_SOURCE;
    switch (data.t) {
      case "hello":
        return finite(data.version) ? { source, t: "hello", version: data.version } : null;
      case "voyage": {
        const voyage = parseVoyageState(data.voyage);
        return voyage ? { source, t: "voyage", voyage } : null;
      }
      case "cards":
        return Array.isArray(data.cards) ? { source, t: "cards", cards: sanitizeCards(data.cards) } : null;
      case "claim-rewards":
        return { source, t: "claim-rewards" };
      case "ack-rewards":
        if (!Array.isArray(data.ids)) return null;
        return {
          source,
          t: "ack-rewards",
          ids: data.ids.filter((id) => typeof id === "string" && id.length <= 200).slice(0, MAX_ACK_IDS)
        };
      default:
        return null;
    }
  }

  // src/shared/runtime.ts
  async function sendToBackground(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      return reply ?? null;
    } catch {
      return null;
    }
  }

  // src/content/bridge.ts
  var META_WAIT_MS = 1e4;
  function isShipPage() {
    return document.querySelector(`meta[name="${SHIP_APP_META}"][content="1"]`) !== null;
  }
  function post(message) {
    window.postMessage(message, location.origin);
  }
  async function forward(message) {
    const reply = await sendToBackground({ t: "web", msg: message });
    if (reply) post(reply);
  }
  function startBridge() {
    window.addEventListener("message", (event) => {
      if (event.source !== window) return;
      const message = parseWebMessage(event.data);
      if (message && isShipPage()) void forward(message);
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.t === "lookout-stats" && isShipPage()) post({ source: LOOKOUT_SOURCE, t: "stats", stats: message.stats });
      return false;
    });
    const announce = () => void forward({ source: WEB_SOURCE, t: "hello", version: BRIDGE_PROTOCOL_VERSION });
    const whenShip = () => {
      if (isShipPage()) return announce();
      const observer = new MutationObserver(() => {
        if (!isShipPage()) return;
        observer.disconnect();
        announce();
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => observer.disconnect(), META_WAIT_MS);
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", whenShip, { once: true });
    else whenShip();
  }
  if (!globalThis.__shipLookoutBridge) {
    globalThis.__shipLookoutBridge = true;
    startBridge();
  }
})();
